# PatientsCommentsCrawl
爬取针对每个医生的患者评论数据，保存为 txt 文件，每个文件为一个医生，每个文件内一行是评论数据。使用 scrapy 来进行爬取。目前数据源只有好大夫。
